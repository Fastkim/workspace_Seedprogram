import ReactDOM from 'react-dom/client'
import App from './1.basic/App'

ReactDOM.createRoot(
    document.getElementById('root')
).render(<App/>)