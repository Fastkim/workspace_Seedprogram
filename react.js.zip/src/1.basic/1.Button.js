// component ==> ui piece
// component를 js 객체로 표현 ==> frame
// presentation logic + appearance
export default function Button() {
    return (
        <button>I'm a button.</button>
    )
}
// HTML 코드가 아니다.